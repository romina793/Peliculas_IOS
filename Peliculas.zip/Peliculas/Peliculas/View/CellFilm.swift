//
//  CellFilm.swift
//  Peliculas
//
//  Created by rpozzuto on 10/03/2020.
//  Copyright © 2020 rpozzuto. All rights reserved.
//

import UIKit

class CellFilm: UITableViewCell {
    
    
    @IBOutlet weak var labelTitle: UILabel!
    
    @IBOutlet weak var imageBackColor: UIImageView!
    
    
    
    static var identifier : String {
        return String(describing: self)
    }
    
    static var nib : UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
}
