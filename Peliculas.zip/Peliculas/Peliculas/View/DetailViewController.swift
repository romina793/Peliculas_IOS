//
//  DetailViewController.swift
//  Peliculas
//
//  Created by rpozzuto on 10/03/2020.
//  Copyright © 2020 rpozzuto. All rights reserved.
//

import UIKit
import AlamofireImage


class DetailViewController: UIViewController {
    
    @IBOutlet var viewColor: UIView!
    @IBOutlet weak var imagePoster: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelDescription: UILabel!


    var viewModel: FilmDetailViewModelContract?

    
    override func viewDidLoad() {
        self.setConfigurationText()
    }
    
    func setConfigurationText() {
        self.imagePoster.image = self.viewModel?.getImageFilm()
        self.labelTitle.text = self.viewModel?.getTitleFilm()
        self.labelDescription.text = self.viewModel?.getDescriptionFilm()
    }

    
}
    


extension DetailViewController: FilmDetailViewModelUpdate {
    
    
    func showLoading() {
//        self.loading()
    }
    
    func showError() {
        let alert = UIAlertController(title: "Error", message: "¡Ups! Hubo un error, por favor intenta más tarde.", preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel)
        alert.addAction(action)
        self.present(alert, animated: true)
        return;    }
    
}
